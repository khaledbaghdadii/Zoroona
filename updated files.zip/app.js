var mysql = require("mysql");
const { addManager, loginManager } = require("./routes/manager");
const { addClient, loginClient } = require("./routes/client");
const { addPlace, showPlaces } = require("./routes/place");
const { showPlace } = require("./routes/placePage");
const {addReview, showReviews}= require("./routes/review");
const {auth,authLogin} =require("./helpers/auth")
const db = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "password",
  database: "zoroona",
});

global.db = db;

const express = require("express");
app = express();
const bodyParser = require("body-parser");
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());


//Home page
app.get("/",(req,res)=>{
  showPlaces(req,res);
})
//Signup as manager
app.post("/signupmanager", (req, res) => {
  addManager(req, res);
});

//Signup as client
app.post("/signupclient", (req, res) => {
  addClient(req, res);
});

//Add a place to databse
app.post("/addplace", (req, res) => {
  addPlace(req, res);
});

//Add review to place
app.post("/addreview",(req,res)=>{
  addReview(req,res);
})

app.post("/loginmanager", (req, res) => {
  //const { email, password } = req.body;
 loginManager(req, res);
  
});
app.post("/loginclient", (req, res) => {
  //const { email, password } = req.body;
 loginClient(req, res);
  
});

app.get("/managerssecret",auth,(req,res)=>{
  res.send("You are a manager! That's the secret");
})

//Selected Place API 
app.route("/places/:placeId")
.get((req,res)=>{
  showPlace(req,res);
});

const port = process.env.PORT || 5000;

app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});

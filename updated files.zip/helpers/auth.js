const jwt = require("jsonwebtoken")

module.exports={
    auth:  (req,res,next)=>{
        const token = req.headers.authorization.split(" ")
        try {if(token[0]==="Bearer" && jwt.verify(token[1],"thesecretkey")){
            next();
    
        }}
        catch(e){
            res.sendStatus(401)
    
        }
    },
    authLogin: (req,res,next)=>{
        const token = req.headers.authorization.split(" ")
        try {if(token[0]==="Bearer" && jwt.verify(token[1],"thesecretkeyclient")){
            next();
    
        }}
        catch(e){
            res.sendStatus(401)
    
        }
    }
}
